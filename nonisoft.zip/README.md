# Student-Management-System
A Student Management System for Noni Softtech. When logging in the site leads to a login form where he can choose whether he can login as Admin/User. He can also select the category, class and session.
database folder contains the database file.

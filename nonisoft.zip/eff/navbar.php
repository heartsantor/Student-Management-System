<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">EFF</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">EFF</a></li>
      <li><a href="#">Student List</a></li>
      <li><a href="#">Admit Card</a></li>
      <li><a href="#">Marks Input</a></li>
      <li><a href="#">Marks Sheet</a></li>
      <li><a href="#">Tabulation</a></li>
      <li><a href="#">Transcript</a></li>
      <li><a href="#">Merit List</a></li>
      <li><a href="#">Search</a></li>
        <?php
        if($_SESSION['role']=='admin')
        {
        ?>
      <li><a href="#">Settings</a></li>
      <li><a href="../settings/">Global Settings</a></li>
        <?php
        }
            ?>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</nav>
